# © By Shashank shukla (Github = itzshukla) You are motherfucker if you Don't gives credits.

from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import Message
from Shashank.modules.help import add_command_help


spam_chats = []


def get_arg(message: Message):
    msg = message.text
    msg = msg.replace(" ", "", 1) if msg[1] == " " else msg
    split = msg[1:].replace("\n", " \n").split(" ")
    if " ".join(split[1:]).strip() == "":
        return ""
    return " ".join(split[1:])

@Client.on_message(filters.command("onetag", ".") & filters.me)
async def mentionall(client: Client, message: Message):
    chat_id = message.chat.id
    direp = message.reply_to_message
    args = get_arg(message)
    if not direp and not args:
        return await message.edit("**sᴇɴᴅ ᴍᴇ ᴀ ᴍᴇssᴀɢᴇ ᴏʀ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴍᴇssᴀɢᴇ!**")
    await message.delete()
    spam_chats.append(chat_id)
    usrnum = 0
    usrtxt = ""
    async for usr in client.get_chat_members(chat_id):
        if not chat_id in spam_chats:
            break
        usrnum += 1
        usrtxt += f"[{usr.user.first_name}](tg://user?id={usr.user.id}), "
        if usrnum == 1:
            if args:
                txt = f"{args}\n\n{usrtxt}"
                await client.send_message(chat_id, txt)
            elif direp:
                await direp.reply(usrtxt)
            await sleep(1)
            usrnum = 0
            usrtxt = ""
    try:
        spam_chats.remove(chat_id)
    except:
        pass


@Client.on_message(filters.command("cancel", ".") & filters.me)
async def cancel_spam(client: Client, message: Message):
    if not message.chat.id in spam_chats:
        return await message.edit("**ɪᴛ sᴇᴇᴍs ᴛʜᴇʀᴇ ɪs ɴᴏ ᴛᴀɢᴀʟʟ ʜᴇʀᴇ.**")
    else:
        try:
            spam_chats.remove(message.chat.id)
        except:
            pass
        return await message.edit("**ᴄᴀɴᴄᴇʟʟᴇᴅ.**")


add_command_help(
    "tagall",
    [
        [
            "onetag [text/reply ke chat]",
            "Tag the members one by one",
        ],
        [
            "cancel",
            f"to stop .onetag",
        ],
    ],
)